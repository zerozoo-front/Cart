export const DropdownInput = {
  select0: '선택해주세요',
  select1: '직접 배송: 판매자가 직접 배송 (3,000원)',
  select2: '픽업: 정해진 시간에 픽업 (0원)',
  select3: '택배 배송 (5,000원)',
};
